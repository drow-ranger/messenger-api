export class ExistingUserDTO {
  email: string;
  password: string;
}
