export class NewUserDTO {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
}
